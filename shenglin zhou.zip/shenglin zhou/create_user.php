<html>  
<body>
<?php

$database = new SQLite3('db.sqlite');
$database->exec('CREATE TABLE IF NOT EXISTS users (user_name varchar(255),password varchar (255),salt varchar (255))');
//echo "table database successfully\n";

?>
<h1> Create new user</h1>
<form method="POST">
Name: <input type="text" name="user_name"><br>
password: <input type="text" name="password"><br>

<input type="submit">
</form>
<?php
	if(isset($_POST['user_name']) && isset($_POST['password'])){
		$user_name=$_POST['user_name'];
		$password=$_POST['password'];
		$uppercase = preg_match('@[A-Z]@', $password);
		$lowercase = preg_match('@[a-z]@', $password);
		$number    = preg_match('@[0-9]@', $password);

		if(!$uppercase || !$lowercase || !$number || strlen($password) < 8) {
  			echo "the password is too simple\n";
		}
		
		$salted=uniqid(mt_rand(), true);
		$hashed=hash('sha512',$salted.$password."dghjghfj");
		#echo $hashed;
		$database->exec("INSERT INTO users(user_name,password,salt) VALUES ('$user_name','$hashed','$salted')");
		//echo "Opened database successfully\n";
	}
?>
</body>
</html>

